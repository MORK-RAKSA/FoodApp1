1 - Install Bunifu &' Exit Visual Studio
2 - Go to the Package folder &' Replace Bunifu.Licensing.dll with the cracked file.
3 - Start Visual Studio &' enjoy
